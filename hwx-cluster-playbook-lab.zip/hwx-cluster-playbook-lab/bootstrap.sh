#!/bin/bash

#set Hosts Inventory
#export ANSIBLE_INVENTORY=$PWD/uat_hosts_ansible
export ANSIBLE_INVENTORY=$PWD/lab_hosts_ansible
#example
#ansible-playbook release.yml --extra-vars "hosts=vipers user=starbuck"


#Actual Commands
if [ $1 == "--check" ];then
echo "##########################################################################"
echo "####################### Dry Run Only #####################################"
echo "##########################################################################"
ansible-playbook bootstrap.yml --check --extra-vars "user=hwadmin"
else
echo "##########################################################################"
echo "####################### Actual Install Run################################"
echo "##########################################################################"
ansible-playbook bootstrap.yml --extra-vars "user=hwadmin"
fi

