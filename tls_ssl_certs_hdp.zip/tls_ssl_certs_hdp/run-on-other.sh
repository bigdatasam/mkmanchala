#!/bin/bash

#run this only after copying the allcerts.tar file
echo "Copy all certs.tar file that was prepared"
tar -vxf allcerts.tar
sudo cp -r hadoop/tls /hadoop/
echo "Creating a privileged store starting with the one included in the JDK"
sudo cp /usr/jdk64/jdk1.8.0_112/jre/lib/security/cacerts /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts
echo "Importing OUR CharterCA file into the CA truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool -noprompt -importcert -trustcacerts -alias chtrenterpriserootca -file /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem -keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts -storepass changeit

sudo /usr/jdk64/jdk1.8.0_112/bin/keytool -noprompt -importcert -trustcacerts -alias chtrenterpriseinterca -file /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem -keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts -storepass changeit

sudo /usr/jdk64/jdk1.8.0_112/bin/keytool -noprompt -importcert -trustcacerts -alias chtrenterpriseinter2ca -file /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem -keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts -storepass changeit

sudo cp /hadoop/tls/security/x509/`hostname -f`.pem /hadoop/tls/security/x509/cert.pem
sudo cp /hadoop/tls/security/x509/`hostname -f`.key /hadoop/tls/security/x509/key.pem
sudo cp /hadoop/tls/security/x509/`hostname -f`-keynopw.pem /hadoop/tls/security/x509/keynopw.pem
sudo cp /hadoop/tls/security/jks/`hostname -f`.jks /hadoop/tls/security/jks/keystore.jks


