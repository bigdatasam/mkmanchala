#!/bin/bash
echo "Importing the Charter CA Certificate file into the java keystore .."
for i in `cat $pathtohostsfile`; do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriserootca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem \
-keystore /hadoop/tls/security/jks/$pfx_prefix$i.jks \
-storepass $strpass \
-keypass $strpass
done


echo "Importing the Charter CA Intermediate Certificate file into the java keystore .."
for i in `cat $pathtohostsfile`; do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriseinterca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem \
-keystore /hadoop/tls/security/jks/$pfx_prefix$i.jks \
-storepass $strpass \
-keypass $strpass
done

echo "Importing the Charter Intermediate2 CA Certificate file into the java keystore .."
for i in `cat $pathtohostsfile`; do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriseinter2ca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem \
-keystore /hadoop/tls/security/jks/$pfx_prefix$i.jks \
-storepass $strpass \
-keypass $strpass
done

echo "done .."
