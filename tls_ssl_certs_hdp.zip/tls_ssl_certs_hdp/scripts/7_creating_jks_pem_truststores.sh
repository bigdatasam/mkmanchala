#!/bin/bash 
echo "Creating jks/pem keystores...."
echo "Add chtr CA cert to truststore"

sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chrenterpriseca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem \
-keystore /hadoop/tls/security/truststore/truststore.jks \
-storepass $strpass

echo "Add chtr CA inter cert to truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chrenterpriseinterca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem \
-keystore /hadoop/tls/security/truststore/truststore.jks \
-storepass $strpass

echo "Add chtr CA inter2 cert to truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chrenterpriseinter2ca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem \
-keystore /hadoop/tls/security/truststore/truststore.jks \
-storepass $strpass

echo "For each host add the cert to the truststore"
for i in `cat $adnodes`;
do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias $i \
-file /hadoop/tls/security/ldapcerts/$i.pem \
-keystore /hadoop/tls/security/truststore/truststore.jks \
-storepass $strpass
done

echo "For each host add the cert to the truststore"
for i in `cat $pathtohostsfile`; do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias $i \
-file /hadoop/tls/security/x509/$pfx_prefix$i.pem \
-keystore /hadoop/tls/security/truststore/truststore.jks \
-storepass $strpass
done


echo "create hue truststore. Because we're using a CA signed"
echo "cert, we put the CA cert chain into the hue truststore"

sudo cat /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem > /tmp/hue-truststore.pem
sudo cat /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem > /tmp/hue-truststore.pem
sudo cat /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem > /tmp/hue-truststore.pem

sudo mv /tmp/hue-truststore.pem /hadoop/tls/security/truststore/hue-truststore.pem

for i in `cat $pathtohostsfile`; do
sudo cat /hadoop/tls/security/x509/$pfx_prefix$i.pem >> /hadoop/tls/security/truststore/hue-truststore.pem
done


echo "Creating TAR file with all certs for distributing"
sudo tar cf allcerts.tar /hadoop/tls/security
sudo chmod 755  allcerts.tar

echo "completed creating all required certs and trust-store .."
echo "allcerts.tar created   .."
echo "Now copy allcerts.tar file to all other nodes and run run-on-other.sh"


