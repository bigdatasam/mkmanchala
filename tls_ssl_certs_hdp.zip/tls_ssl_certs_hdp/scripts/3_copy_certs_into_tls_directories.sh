#!/bin/bash 
echo "converting charter CA .cer file to .pem" 
sudo cp -f $rootdir/charterca-certs/chtr.enterprise.ca.cer /hadoop/tls/security/ca-certs/
sudo openssl x509 -in /hadoop/tls/security/ca-certs/chtr.enterprise.ca.cer -out /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem
sudo openssl x509 -outform der -in /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem -out /hadoop/tls/security/ca-certs/chtr.enterprise.ca.crt

echo "converting charter Intermediate CA .cer file to .pem" 
sudo cp -f $rootdir/charterca-certs/chtr.enterprise.inter.ca.cer /hadoop/tls/security/ca-certs/
sudo openssl x509 -in /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.cer -out /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem
sudo openssl x509 -outform der -in /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem -out /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.crt

echo "converting charter Intermediate 2 CA .cer file to .pem" 
sudo cp -f $rootdir/charterca-certs/chtr.enterprise.inter2.ca.cer /hadoop/tls/security/ca-certs/
sudo openssl x509 -in /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.cer -out /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem
sudo openssl x509 -outform der -in /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem -out /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.crt

for i in `cat $adnodes`;
do
echo "converting AD charter CA .cer file to .pem"
sudo cp -f $rootdir/ldapcerts/$i.cer /hadoop/tls/security/ldapcerts/
sudo openssl x509 -in /hadoop/tls/security/ldapcerts/$i.cer -out /hadoop/tls/security/ldapcerts/$i.pem
done

echo "importing .jks files to /hadoop/tls/security/jks/ .."
sudo cp -f jks_files/* /hadoop/tls/security/jks/

echo "importing .pfx files to /hadoop/tls/security/tmp/ .." 
sudo cp -f pfx_files/* /hadoop/tls/security/tmp/


