#!/bin/bash
echo "Converting .pfx to .jks..."
[ -e /tmp/aliases.txt ] && rm -f /tmp/aliases.txt
rm -f jks_files/*
for i in `cat $pathtohostsfile`;
do
alias_in_pfx=$(sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-list \
-keystore pfx_files/$pfx_prefix$i.pfx \
-storetype PKCS12 \
-storepass $strpass \
| grep -i privatekeyentry \
| cut -d',' -f 1)
echo $i " " $alias_in_pfx >> /tmp/aliases.txt
done



while read i j;
do 
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importkeystore \
-srckeystore pfx_files/$pfx_prefix$i.pfx \
-srcalias $j \
-destalias $i \
-srcstorepass $strpass \
-srcstoretype pkcs12 \
-destkeystore jks_files/$pfx_prefix$i.jks \
-deststoretype JKS \
-storepass $strpass
done < /tmp/aliases.txt
[ -e /tmp/aliases.txt ] && rm -f /tmp/aliases.txt
echo "Done"

