#!/bin/bash

echo "changing the permissions as required .."
sudo chmod 0755 /hadoop/tls/
sudo chmod 0755 /hadoop/tls/security/
sudo chmod 0755 /hadoop/tls/security/ca-certs
sudo chmod 0755 /hadoop/tls/security/jks
sudo chmod 0755 /hadoop/tls/security/tmp
sudo chmod 0755 /hadoop/tls/security/certs
sudo chmod 0755 /hadoop/tls/security/truststore
sudo chmod 0644 /hadoop/tls/security/x509/*
sudo chmod 0644 /hadoop/tls/security/ca-certs/*
sudo chmod 0644 /hadoop/tls/security/jks/*
sudo chmod 0644 /hadoop/tls/security/tmp/*
sudo chmod 0644 /hadoop/tls/security/truststore/*
sudo chmod 0644 /hadoop/tls/security/x509/*
sudo chmod 0644 /hadoop/tls/security/ldapcerts/*
sudo chmod 0644 /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts



