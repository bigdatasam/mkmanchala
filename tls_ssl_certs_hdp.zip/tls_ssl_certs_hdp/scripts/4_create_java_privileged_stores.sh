#!/bin/bash 
echo "Creating a privileged store starting with the one included in the JDK"
sudo cp /usr/jdk64/jdk1.8.0_112/jre/lib/security/cacerts /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts

echo "Importing OUR CharterCA file into the CA truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriserootca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.ca.pem \
-keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts \
-storepass changeit

echo "Importing OUR CharterCA Intermediate file into the CA truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriseinterca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter.ca.pem \
-keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts \
-storepass changeit

echo "Importing OUR CharterCA Intermediate2 file into the CA truststore"
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias chtrenterpriseinter2ca \
-file /hadoop/tls/security/ca-certs/chtr.enterprise.inter2.ca.pem \
-keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts \
-storepass changeit

for i in `cat $adnodes`;
do
sudo /usr/jdk64/jdk1.8.0_112/bin/keytool \
-noprompt \
-importcert \
-trustcacerts \
-alias $i \
-file /hadoop/tls/security/ldapcerts/$i.pem \
-keystore /usr/jdk64/jdk1.8.0_112/jre/lib/security/jssecacerts \
-storepass changeit
done
