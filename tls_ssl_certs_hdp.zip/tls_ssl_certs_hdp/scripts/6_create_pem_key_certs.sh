#!/bin/bash 
echo "creating .pem, .key, .keynopw (via .key) from pfx files .."
for i in `cat $pathtohostsfile`; do \
sudo openssl pkcs12 -in /hadoop/tls/security/tmp/$pfx_prefix$i.pfx \
-clcerts \
-passin pass:$strpass \
-nokeys \
-out /hadoop/tls/security/x509/$pfx_prefix$i.pem
done

for i in `cat $pathtohostsfile`; do \
sudo openssl pkcs12 -in /hadoop/tls/security/tmp/$pfx_prefix$i.pfx \
-passin pass:$strpass \
-passout pass:$strpass \
-nocerts \
-out /hadoop/tls/security/x509/$pfx_prefix$i.key
done

for i in `cat $pathtohostsfile`; do \
sudo openssl pkcs12 -in /hadoop/tls/security/tmp/$pfx_prefix$i.pfx \
-nokeys \
-clcerts \
-passin pass:$strpass \
-out /hadoop/tls/security/x509/$pfx_prefix$i.crt
done

for i in `cat $pathtohostsfile`; do \
sudo openssl x509 -in /hadoop/tls/security/x509/$pfx_prefix$i.crt \
-inform pem \
-outform der \
-out /hadoop/tls/security/x509/$pfx_prefix$i.cer
done

for i in `cat $pathtohostsfile`; do
sudo openssl rsa \
-in /hadoop/tls/security/x509/$pfx_prefix$i.key \
-passin pass:$strpass \
-out /hadoop/tls/security/x509/$pfx_prefix$i-keynopw.pem
done

echo "done .."
