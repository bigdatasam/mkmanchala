#!/bin/bash 
echo "creating directory structure for holding the certs .."
sudo mkdir -p /hadoop/tls/security/ca-certs
sudo mkdir -p /hadoop/tls/security/jks 
sudo mkdir -p /hadoop/tls/security/tmp
sudo mkdir -p /hadoop/tls/security/certs
sudo mkdir -p /hadoop/tls/security/truststore
sudo mkdir -p /hadoop/tls/security/x509
sudo mkdir -p /hadoop/tls/security/ldapcerts

echo "changing the permissions as required .."
sudo chmod 0755 /hadoop/tls/
sudo chmod 0755 /hadoop/tls/security/
sudo chmod -R 0755 /hadoop/tls/security/ca-certs
sudo chmod -R 0755 /hadoop/tls/security/jks
sudo chmod -R 0755 /hadoop/tls/security/tmp
sudo chmod -R 0755 /hadoop/tls/security/certs
sudo chmod -R 0755 /hadoop/tls/security/truststore
sudo chmod -R 0755 /hadoop/tls/security/x509
sudo chmod -R 0755 /hadoop/tls/security/ldapcerts

