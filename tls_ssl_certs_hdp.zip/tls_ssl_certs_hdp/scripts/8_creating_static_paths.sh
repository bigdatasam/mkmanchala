#!/bin/bash
#pfx_prefix="0402_2020_"
sudo cp /hadoop/tls/security/x509/`hostname -f`.pem /hadoop/tls/security/x509/cert.pem
sudo cp /hadoop/tls/security/x509/`hostname -f`.key /hadoop/tls/security/x509/key.pem
sudo cp /hadoop/tls/security/x509/`hostname -f`-keynopw.pem /hadoop/tls/security/x509/keynopw.pem
sudo cp /hadoop/tls/security/jks/`hostname -f`.jks /hadoop/tls/security/jks/keystore.jks
sudo cp /hadoop/tls/security/x509/`hostname -f`.crt /hadoop/tls/security/x509/cert.crt
sudo cp /hadoop/tls/security/x509/`hostname -f`.cer /hadoop/tls/security/x509/cert.cer
