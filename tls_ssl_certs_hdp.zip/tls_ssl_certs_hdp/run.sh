source /root/tls_ssl_certs_hdp/variables
source /root/tls_ssl_certs_hdp/scripts/1_create_directories.sh
source /root/tls_ssl_certs_hdp/scripts/2_convert_pfx_to_jks.sh
source /root/tls_ssl_certs_hdp/scripts/3_copy_certs_into_tls_directories.sh
source /root/tls_ssl_certs_hdp/scripts/4_create_java_privileged_stores.sh
source /root/tls_ssl_certs_hdp/scripts/5_importing_charter-ca_to_jks.sh
source /root/tls_ssl_certs_hdp/scripts/6_create_pem_key_certs.sh
source /root/tls_ssl_certs_hdp/scripts/7_creating_jks_pem_truststores.sh
source /root/tls_ssl_certs_hdp/scripts/8_creating_static_paths.sh
source /root/tls_ssl_certs_hdp/scripts/9_set_permissions.sh


